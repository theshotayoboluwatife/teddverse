import React, { useEffect, useState } from 'react';
import Modal from 'react-modal';
import { Close } from '@mui/icons-material';
import axios from 'axios';

const ProfileModal = ({ isOpen, onRequestClose }) => {
  const [animation, setAnimation] = useState(false);
  const [formData, setFormData] = useState({
    username: '',
    underDesi: false,
    wagered: false,
  });
  const [formError, setFormError] = useState('');

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden'; // Disable scrolling
    } else {
      document.body.style.overflow = 'auto'; // Enable scrolling
    }
    return () => {
      document.body.style.overflow = 'auto'; // Clean up on unmount
    };
  }, [isOpen]);

  useEffect(() => {
    setAnimation(true);
    const timer = setTimeout(() => setAnimation(false), 500); // Match duration with CSS transition
    return () => clearTimeout(timer);
  }, []);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = async () => {
    if (!formData.username || !formData.underDesi || !formData.wagered) {
      setFormError('All fields must be filled out');
      return;
    }

    setFormError('');

    try {
      const response = await axios.post('https://api.coneiz.com/api/desi/send', formData);
      onRequestClose();
    } catch (error) {
      console.error('Error submitting claim profile', error);
      setFormError('Error submitting claim profile');
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onRequestClose={onRequestClose}
      style={{
        content: {
          width: '400px',
          height: 'auto',
          margin: 'auto',
          borderRadius: '10px',
          background: 'linear-gradient(317deg, #000000, #166D3B)',
          color: 'white',
          padding: '0',
          overflow: 'hidden',
        },
        overlay: {
          backgroundColor: 'rgba(0, 0, 0, 0.75)',
        },
      }}
    >
      <div style={{ position: 'relative' }}>
        <div style={{
          backgroundImage: 'url("https://media.discordapp.net/attachments/1244370008411209811/1268805754329235477/standard_1.gif?ex=66adc2f1&is=66ac7171&hm=628d74fc1a7c354ec37a85f7fd16536815d503c7036e64edf892b7e28868ed17&=&width=675&height=270")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          height: '150px',
        }}></div>
        <div style={{ position: 'absolute', top: '10px', right: '10px', cursor: 'pointer' }} onClick={onRequestClose}>
          <Close style={{ color: 'white' }} />
        </div>
        <div style={{ padding: '20px', marginTop: '-70px', zIndex: 1, position: 'relative' }}>
          <div
            style={{
              transition: 'opacity 0.5s ease, transform 0.5s ease',
              opacity: animation ? 0 : 1,
              transform: animation ? 'translateX(20px)' : 'translateX(0)',
            }}
          >
            <div style={{ textAlign: 'center' }}>
              <h2 style={{ marginBottom: '10px' }}>Claim 35$</h2>
              <div style={{ marginBottom: '10px', textAlign: 'left' }}>
                <h4 style={{ marginBottom: '5px' }}>Username</h4>
                <input
                  type="text"
                  name="username"
                  value={formData.username}
                  onChange={handleInputChange}
                  style={{
                    backgroundColor: '#000000',
                    padding: '5px 10px',
                    borderRadius: '10px',
                    color: 'white',
                    width: '100%',
                    border: 'none',
                    outline: 'none',
                    textAlign: 'center',
                  }}
                  placeholder="Enter your username"
                />
              </div>
              <div style={{ marginBottom: '10px', textAlign: 'left' }}>
                <h4 style={{ marginBottom: '5px' }}>Are you under "desi2023"?</h4>
                <label style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  backgroundColor: '#000000',
                  padding: '5px 10px',
                  borderRadius: '10px',
                  color: 'white',
                }}>
                  <input type="checkbox" name="underDesi" checked={formData.underDesi} onChange={handleInputChange} style={{ transform: 'scale(0.8)' }} />
                  <span>Yes</span>
                </label>
              </div>
              <div style={{ marginBottom: '10px', textAlign: 'left' }}>
                <h4 style={{ marginBottom: '5px' }}>Have you deposited and wagered $35?</h4>
                <label style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  backgroundColor: '#000000',
                  padding: '5px 10px',
                  borderRadius: '10px',
                  color: 'white',
                }}>
                  <input type="checkbox" name="wagered" checked={formData.wagered} onChange={handleInputChange} style={{ transform: 'scale(0.8)' }} />
                  <span>Yes</span>
                </label>
              </div>
              {formError && <p style={{ color: 'red', textAlign: 'center' }}>{formError}</p>}
              <button
                onClick={handleSubmit}
                style={{
                  background: '#166D3B',
                  color: 'white',
                  padding: '10px 20px',
                  borderRadius: '10px',
                  border: 'none',
                  cursor: 'pointer',
                  fontSize: '14px',
                  marginTop: '10px',
                  transition: 'background 0.3s ease',
                }}
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
};

export default ProfileModal;
