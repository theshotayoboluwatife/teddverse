import React, { useState } from 'react';
import ProfileModal from './ProfileModal'; // Import ProfileModal
import { logo } from "../assets";

const Navbar = () => {
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false); // State for ProfileModal

  const openProfileModal = () => setIsProfileModalOpen(true); // Function to open ProfileModal
  const closeProfileModal = () => setIsProfileModalOpen(false); // Function to close ProfileModal

  return (
    <>
      <nav className='w-full flex py-6 justify-between items-center navbar'>
        <img src={logo} alt='Desi' className='w-[60px] h-[60px]' />
        <button
          className='px-6 py-3 rounded-full font-poppins font-semibold text-white uppercase'
          style={{
            backgroundImage: 'linear-gradient(317deg, #5865F2, #404EED)',
          }}
          onClick={openProfileModal}
        >
          Claim 35$
        </button>
      </nav>
      <ProfileModal isOpen={isProfileModalOpen} onRequestClose={closeProfileModal} /> {/* Add ProfileModal */}
    </>
  );
};

export default Navbar;
