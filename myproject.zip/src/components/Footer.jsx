import React from 'react'
import styles from '../style'
import { logo, gambleaware, ager, desigamblers } from '../assets'
import { footerLinks, socialMedia } from '../constants'

const Footer = () => {
  return (
    <section className={`${styles.flexCenter} ${styles.paddingY} flex-col`}>
      <div className={`${styles.flexStart} md:flex-row flex-col mb-8 w-full`}>
        <div className='flex-1 flex flex-col justify-start mr-10'>
          <img
            src={logo}
            alt='logo'
            className='w-[100px] h-[100px] object-contain'
          />
          <div className='flex flex-row items-center mt-4'>
            <img
              src={gambleaware} 
              alt='gambleaware'
              className='w-[133px] h-[82px] object-contain'
            />
            <img 
              width="50" 
              height="50" 
              src="https://img.icons8.com/ios/50/FA5252/18-plus.png" 
              alt="18-plus"
              className='ml-4'
            />
          </div>
          <p className={`${styles.paragraph} mt-4 w-full text-left border p-4 text-[10px]`}>
            WE DO NOT TAKE RESPONSIBILITY FOR ANY LOSSES OR WINS FROM GAMBLING IN CASINOS AND BETTING SITES WHICH ARE LINKED OR PROMOTED ON OUR WEBSITE(S). AS A PLAYER, YOU ARE RESPONSIBLE FOR YOUR BETS.
          </p>
        </div>
      </div>
      <div className='w-full flex justify-between items-center md:flex-row flex-col pt-6 border-t-[1px] border-t-[#3F3E45]'>
        <p className='font-poppins font-normal text-center text-[18px] leading-[27px] text-white'>
          © 2024 Desigamblers. All Rights Reserved.
        </p>  
        <div className="flex flex-row md:mt-0 mt-6">
  <a href="https://coneiz.com/" target="_blank" rel="noopener noreferrer">
    <h1 style={{ fontFamily: 'Days One, sans-serif', color: 'white' }}>Made by Coneiz</h1>
  </a>
</div>

      </div>
    </section>
  )
}

export default Footer
