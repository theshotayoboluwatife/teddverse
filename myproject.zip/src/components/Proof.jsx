import React from 'react';
import styles from '../style';

const Proof = () => {
  const videoUrls = [
    'https://cdn.discordapp.com/attachments/1222038507284074521/1265496544006897664/VID_20240721_154212_275_1.mp4?ex=66ad967f&is=66ac44ff&hm=9e45e7fa61f6323e51ce1b81a3faf8f541899a32d095f80b59fd008f35fc5e7a&',
    'https://cdn.discordapp.com/attachments/1222038507284074521/1265496930356826163/VID_20240721_154243_566.mp4?ex=66ad96db&is=66ac455b&hm=5ec2c3e2793a718d8e829758239c84e192458e54796cab9a04d5eb6b911984ed&',
    'https://cdn.discordapp.com/attachments/1222038507284074521/1265497158220644453/VID_20240721_154258_539.mp4?ex=66ad9712&is=66ac4592&hm=33b2eaca494c1c0ea2d429f2b78991afa68f5876647944dc66521ff2a0423aae&',
    'https://cdn.discordapp.com/attachments/1222038507284074521/1265497430862856233/VID_20240721_154315_269.mp4?ex=66ad9753&is=66ac45d3&hm=e8fd3e2b2a899c5a2b850f5d52620c9c0d701632fd29ff6198be9bb8648b856a&',
    'https://cdn.discordapp.com/attachments/1222038507284074521/1265498241835995229/VID_20240721_144310_751.mp4?ex=66ad9814&is=66ac4694&hm=04e6933c734e67189740cc997946e0439957a279bab72250d353e75d52aed7e8&',
    'https://cdn.discordapp.com/attachments/1222038507284074521/1265498359758721127/video-output-D4C06822-94DE-47F0-8ADF-404E12E16F33.mov?ex=66ad9830&is=66ac46b0&hm=8def6db826bbf233be762e70b39ec4fbf5f55c721efc9b48f4cc60e91759bfca&',
    'https://cdn.discordapp.com/attachments/1222038507284074521/1265498625459359754/WhatsApp_Video_2024-06-28_at_5.29.05_PM.mp4?ex=66ad9870&is=66ac46f0&hm=851954022b630ddecfc813a6bb5bb669f82c76628679c459dd98784ada507d8f&',
    'https://cdn.discordapp.com/attachments/1222038507284074521/1265499592942944318/VID_21281110_170827_982.mp4?ex=66ad9956&is=66ac47d6&hm=a9291ad789842928757727b673f167388f01127488997d0e79d978d95caf20cd&'
  ];

  return (
    <section id='proof' className='relative overflow-hidden'>
      <div className='absolute inset-0 -z-10 bg-cover bg-center bg-no-repeat filter blur-[8px] bg-[url("https://wallpapers.com/images/hd/dark-laptop-abstract-smoke-background-41z3e057yvjcei8n.jpg")]' />
      <div className={`${styles.boxWidth} relative z-10`}>
        <h1 className='font-poppins font-semibold ss:text-[72px] text-[52px] ss:leading-[100.8px] leading-[75px] mx-auto text-center'>
          <span className='text-gradient'>Proof</span>.
        </h1>
        <p className={`${styles.paragraph} max-w-[470px] mt-5 mx-auto text-center`}>
          Here you can see all the proofs of our activities and achievements.
        </p>
        <div className='grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mt-8'>
          {videoUrls.map((url, index) => (
            <div key={index} className='w-full flex justify-center'>
              <video className='w-48 h-auto' controls>
                <source src={url} type='video/mp4' />
                Your browser does not support the video tag.
              </video>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Proof;
