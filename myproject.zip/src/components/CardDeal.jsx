import React, { useState, useEffect } from 'react';
import { List, ListItemAvatar, ListItemText, Avatar, Typography, Paper, Box, CircularProgress, Button } from '@mui/material';
import { styled } from '@mui/system';
import EmojiEventsIcon from '@mui/icons-material/EmojiEvents';
import axios from 'axios';
import logo from '../assets/logo.png'; // Ensure the correct path to the logo file

const StyledList = styled(List)({
  borderColor: 'transparent',
});

const StyledBox = styled(Box)(({ theme }) => ({
  borderRadius: '25px',
  padding: '10px 0',
  marginBottom: '10px',
  border: '10px solid',
  borderColor: 'transparent',
  display: 'grid',
  gridTemplateColumns: '50px 1fr 1fr 1fr',
  gap: '10px',
  alignItems: 'center',
  transition: 'transform 0.3s, box-shadow 0.3s',
  '&:hover': {
    transform: 'scale(1.02)',
    boxShadow: `0 4px 8px rgba(0, 0, 0, 0.3)`,
    filter: 'brightness(1.2)',
  },
}));

const StyledAvatar = styled(Avatar)({
  width: 40,
  height: 40,
});

const ColumnHeaders = styled(Box)({
  display: 'grid',
  gridTemplateColumns: '40px 1fr 1fr 1fr',
  gap: '10px',
  padding: '10px 0',
  borderBottom: '1px solid rgba(51, 51, 51, 0.8)',
  marginBottom: '10px',
});

const GradientText = styled(Typography)({
  background: 'linear-gradient(135deg, #6e8efb 0%, #a777e3 100%)',
  WebkitBackgroundClip: 'text',
  WebkitTextFillColor: 'transparent',
  textTransform: 'uppercase',
});

const getLoaderColor = (rank) => {
  switch (rank) {
    case 1:
      return '#fdd835'; // Gold
    case 2:
      return '#616161'; // Silver
    case 3:
      return '#8d6e63'; // Bronze
    default:
      return 'white';
  }
};

const Leaderboard = () => {
  const [leaderboardData, setLeaderboardData] = useState([]);
  const [showAll, setShowAll] = useState(false);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const fetchLeaderboardData = async () => {
      try {
        const response = await axios.get('https://api.coneiz.com/api/desi/leaderboard');
        setLeaderboardData(response.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching leaderboard data:', error);
        setLoading(false);
      }
    };

    fetchLeaderboardData();
  }, []);
  
  const handleToggleClick = () => {
    setShowAll(prevShowAll => !prevShowAll);
  };

  if (loading) {
    return <CircularProgress />;
  }

  return (
    <Paper style={{ backgroundColor: 'transparent', padding: '20px', borderRadius: '10px', maxWidth: '1200px', margin: '0 auto' }}>
      <GradientText variant="h5" style={{ textAlign: 'center', marginBottom: '20px' }}>
        Monthly Leaderboard
      </GradientText>
      <ColumnHeaders>
        <Box display="flex" alignItems="center">
          <EmojiEventsIcon style={{ color: 'white', marginRight: '8px' }} />
          <Typography variant="body1" style={{ color: 'white', textAlign: 'center' }}>
            Rank
          </Typography>
        </Box>
        <Typography variant="body1" style={{ color: 'white', textAlign: 'center' }}>User</Typography>
        <Typography variant="body1" style={{ color: 'white', textAlign: 'center' }}>Wagered</Typography>
        <Typography variant="body1" style={{ color: 'white', textAlign: 'center' }}>Prize</Typography>
      </ColumnHeaders>
      <StyledList>
        {leaderboardData.slice(0, showAll ? leaderboardData.length : 3).map((winner, index) => (
          <StyledBox key={index}>
            <Box position="relative" display="flex" alignItems="center" justifyContent="center">
              <CircularProgress 
                style={{ color: getLoaderColor(winner.rank) }}
                disableShrink
              />
              <Box position="absolute">
                <Typography variant="body1" style={{ color: 'white', textAlign: 'center' }}>
                  {winner.rank}
                </Typography>
              </Box>
            </Box>
            <Box style={{ display: 'flex', alignItems: 'center' }}>
              <ListItemAvatar>
                <StyledAvatar alt={winner.name} src={logo} />
              </ListItemAvatar>
              <ListItemText primary={winner.name} style={{ color: 'white' }} />
            </Box>
            <Typography variant="body1" style={{ color: 'white', textAlign: 'center' }}>${winner.wagered}</Typography>
            <Typography variant="body1" style={{ color: 'white', textAlign: 'center' }}>${winner.prize}</Typography>
          </StyledBox>
        ))}
      </StyledList>
      <Box display="flex" justifyContent="center" mt={2}>
        <Button variant="outlined" onClick={handleToggleClick}>
          {showAll ? 'SHOW LESS' : 'SHOW MORE'}
        </Button>
      </Box>
    </Paper>
  );
};

export default Leaderboard;
