import React, { useEffect, useState } from 'react';
import Modal from 'react-modal';
import { Close } from '@mui/icons-material';
import axios from 'axios';

const ProfileModal = ({ isOpen, onRequestClose, user }) => {
  const [activeOption, setActiveOption] = useState('Home');
  const [animation, setAnimation] = useState(false);
  const [formData, setFormData] = useState({
    email: user.email,
    username: '',
    underDesi: false,
    wagered: false,
  });
  const [formError, setFormError] = useState('');

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden'; // Disable scrolling
    } else {
      document.body.style.overflow = 'auto'; // Enable scrolling
    }
    return () => {
      document.body.style.overflow = 'auto'; // Clean up on unmount
    };
  }, [isOpen]);

  useEffect(() => {
    setAnimation(true);
    const timer = setTimeout(() => setAnimation(false), 500); // Match duration with CSS transition
    return () => clearTimeout(timer);
  }, [activeOption]);

  if (!user) return null;

  const handleOptionClick = (option) => {
    setActiveOption(option);
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = async () => {
    if (!formData.username || !formData.underDesi || !formData.wagered) {
      setFormError('All fields must be filled out');
      return;
    }

    setFormError('');

    try {
      const response = await axios.post('http://localhost:5124/api/send', formData);
      console.log('Claim profile submitted', response.data);
      onRequestClose();
    } catch (error) {
      console.error('Error submitting claim profile', error);
      setFormError('Error submitting claim profile');
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onRequestClose={onRequestClose}
      style={{
        content: {
          width: '400px',
          height: 'auto',
          margin: 'auto',
          borderRadius: '10px',
          background: 'linear-gradient(317deg, #000000, #166D3B)',
          color: 'white',
          padding: '0',
          overflow: 'hidden',
        },
        overlay: {
          backgroundColor: 'rgba(0, 0, 0, 0.75)',
        },
      }}
    >
      <div style={{ position: 'relative' }}>
        <div style={{
          backgroundImage: 'url("https://cdn.pixabay.com/photo/2022/06/23/17/13/ball-7280265_1280.jpg")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          height: '150px',
        }}></div>
        <div style={{ position: 'absolute', top: '10px', right: '10px', cursor: 'pointer' }} onClick={onRequestClose}>
          <Close style={{ color: 'white' }} />
        </div>
        <div style={{ padding: '20px', marginTop: '-70px', zIndex: 1, position: 'relative' }}>
          <div
            style={{
              transition: 'opacity 0.5s ease, transform 0.5s ease',
              opacity: animation ? 0 : 1,
              transform: animation ? 'translateX(20px)' : 'translateX(0)',
            }}
          >
            {activeOption === 'Home' ? (
              <div style={{ textAlign: 'center' }}>
                <h2 style={{ marginBottom: '10px' }}>My Profile</h2>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginBottom: '10px' }}>
                  <img
                    src={`https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png`}
                    alt='User Avatar'
                    style={{ width: '100px', height: '100px', borderRadius: '50%', marginBottom: '10px', border: '4px solid white', transition: 'all 0.5s ease' }}
                  />
                  <h3 style={{ fontSize: '20px', marginBottom: '5px' }}>{user.global_name}</h3>
                  <p style={{ marginBottom: '10px', fontSize: '14px' }}>Joined: {new Date(user.joined).toLocaleDateString()}</p>
                </div>
                <div style={{ marginBottom: '10px', textAlign: 'left' }}>
                  <h4 style={{ marginBottom: '5px' }}>Contact</h4>
                  <div style={{
                    backgroundColor: '#000000',
                    padding: '5px 10px',
                    borderRadius: '10px',
                    color: 'white',
                    textAlign: 'center',
                  }}>
                    <p>Email: {user.email}</p>
                  </div>
                </div>
              </div>
            ) : (
              <div style={{ textAlign: 'center' }}>
                <h2 style={{ marginBottom: '10px' }}>Claim Profile</h2>
                <img
                  src={`https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png`}
                  alt='User Avatar'
                  style={{ width: '100px', height: '100px', borderRadius: '50%', marginBottom: '10px', border: '4px solid white', transition: 'all 0.5s ease', transform: 'translateY(-30px)' }}
                />
                <div style={{ marginBottom: '10px', textAlign: 'left' }}>
                  <h4 style={{ marginBottom: '5px' }}>Contact</h4>
                  <div style={{
                    backgroundColor: '#000000',
                    padding: '5px 10px',
                    borderRadius: '10px',
                    color: 'white',
                    textAlign: 'center',
                  }}>
                    <p>Email: {user.email}</p>
                  </div>
                </div>
                <div style={{ marginBottom: '10px', textAlign: 'left' }}>
                  <h4 style={{ marginBottom: '5px' }}>Username</h4>
                  <input
                    type="text"
                    name="username"
                    value={formData.username}
                    onChange={handleInputChange}
                    style={{
                      backgroundColor: '#000000',
                      padding: '5px 10px',
                      borderRadius: '10px',
                      color: 'white',
                      width: '100%',
                      border: 'none',
                      outline: 'none',
                      textAlign: 'center',
                    }}
                    placeholder="Enter your username"
                  />
                </div>
                <div style={{ marginBottom: '10px', textAlign: 'left' }}>
                  <h4 style={{ marginBottom: '5px' }}>Are you under "desi2023"?</h4>
                  <label style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    backgroundColor: '#000000',
                    padding: '5px 10px',
                    borderRadius: '10px',
                    color: 'white',
                  }}>
                    <input type="checkbox" name="underDesi" checked={formData.underDesi} onChange={handleInputChange} style={{ transform: 'scale(0.8)' }} />
                    <span>Yes</span>
                  </label>
                </div>
                <div style={{ marginBottom: '10px', textAlign: 'left' }}>
                  <h4 style={{ marginBottom: '5px' }}>Have you deposited and wagered $35?</h4>
                  <label style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    backgroundColor: '#000000',
                    padding: '5px 10px',
                    borderRadius: '10px',
                    color: 'white',
                  }}>
                    <input type="checkbox" name="wagered" checked={formData.wagered} onChange={handleInputChange} style={{ transform: 'scale(0.8)' }} />
                    <span>Yes</span>
                  </label>
                </div>
                {formError && <p style={{ color: 'red', textAlign: 'center' }}>{formError}</p>}
                <button
                  onClick={handleSubmit}
                  style={{
                    background: '#166D3B',
                    color: 'white',
                    padding: '10px 20px',
                    borderRadius: '10px',
                    border: 'none',
                    cursor: 'pointer',
                    fontSize: '14px',
                    marginTop: '10px',
                    transition: 'background 0.3s ease',
                  }}
                >
                  Submit
                </button>
              </div>
            )}
          </div>
          <div
            style={{
              display: 'flex',
              justifyContent: 'center',
              gap: '10px',
              marginTop: '10px',
            }}
          >
            <button
              onClick={() => handleOptionClick('Home')}
              style={{
                background: activeOption === 'Home' ? '#166D3B' : 'transparent',
                color: activeOption === 'Home' ? 'white' : '#166D3B',
                padding: '10px 20px',
                borderRadius: '10px',
                border: '1px solid #166D3B',
                cursor: 'pointer',
                fontSize: '14px',
                transition: 'background 0.3s ease',
              }}
            >
              Home
            </button>
            <button
              onClick={() => handleOptionClick('Claim')}
              style={{
                background: activeOption === 'Claim' ? '#166D3B' : 'transparent',
                color: activeOption === 'Claim' ? 'white' : '#166D3B',
                padding: '10px 20px',
                borderRadius: '10px',
                border: '1px solid #166D3B',
                cursor: 'pointer',
                fontSize: '14px',
                transition: 'background 0.3s ease',
              }}
            >
              Claim
            </button>
          </div>
        </div>
      </div>
    </Modal>
  );
};

export default ProfileModal;
